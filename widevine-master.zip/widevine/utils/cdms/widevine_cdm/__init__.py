# Standard Libraries
import binascii
import os
import json
import base64
import time

from Cryptodome.Random import get_random_bytes
from Cryptodome.Random import random
from Cryptodome.Cipher import PKCS1_OAEP, AES
from Cryptodome.Hash import CMAC, SHA256, HMAC, SHA1
from Cryptodome.PublicKey import RSA
from Cryptodome.Signature import pss
from Cryptodome.Util import Padding

from google.protobuf.message import DecodeError
from google.protobuf import text_format
from utils.cdms.widevine_cdm.formats import wv_proto2_pb2 as wv_proto2


class AddOn(object):

    IDENTITY = "widevine_cdm"
    system_id = [237, 239, 139, 169, 121, 214, 74, 206, 163, 200, 39, 220, 213, 29, 33, 237]
    urn = 'urn:uuid:EDEF8BA9-79D6-4ACE-A3C8-27DCD51D21ED'

    def __init__(self, device):
        self.cdm = Cdm()
        self.cdm.device = Device(device)
        self.session = None
        # Stubs
        self.pssh = None
        self.pssh_raw = None
        self.certificate = None
        self.license = None

    # ==== #
    # Open
    # ==== #
    def open(self, offline=False):
        """
        Opens a new CDM session with the current pssh&pssh_raw
        """
        if self.pssh is not None:
            # Base64 Encoded PSSH to Bytes
            pssh = base64.b64decode(self.pssh)
            # Make sure the PSSH is valid
            if pssh[12:28] != bytes(self.system_id):
                t = bytearray([0, 0, 0])
                t.append(32 + len(pssh))
                t[4:] = bytearray(b'pssh')
                t[8:] = [0, 0, 0, 0]
                t[13:] = self.system_id
                t[29:] = [0, 0, 0, 0]
                t[31] = len(pssh)
                t[32:] = pssh
                self.pssh = base64.b64encode(t)
        # Open a Session with the PSSH
        # For key exchange: None, b'\x0A\x7A\x00\x6C\x38\x2B', True
        self.session = self.cdm.open(self.pssh, self.pssh_raw, offline)

    # ======= #
    # License
    # ======= #
    def get_license(self, raw=False):
        """
        Returns base64-encoded string license to be sent off to services' license request api's
        """
        b = self.cdm.get_license_request(self.session)
        return base64.b64encode(b).decode('utf-8') if not raw else b

    def provide_license(self, license_base64):
        """
        Provides the given base64 string to the CDM session for decryption
        """
        self.cdm.provide_license(self.session, license_base64)

    # =========== #
    # Certificate
    # =========== #
    def get_certificate(self, raw=False):
        """
        Returns base64-encoded string certificate to be sent off to services' license request api's
        """
        b = b'\x08\x04'
        return base64.b64encode(b).decode('utf-8') if not raw else b

    def provide_certificate(self, cert_base64):
        """
        Provides the given base64 string to the CDM session for VMP
        """
        self.cdm.set_service_certificate(self.session, cert_base64)

    # ==== #
    # Keys
    # ==== #
    def get_keys(self, content_only=True):
        """
        Returns decryption keys
        """
        for key in self.cdm.get_keys(self.session):
            if content_only:
                if key.type == 'CONTENT':
                    yield f"{key.kid.hex()}:{key.key.hex()}"
            else:
                yield key

    def get_decryption_keys(self):
        """
        Prepare/Arm the CDM for decryption and return decryption keys
        :return: decryption keys
        """
        # Open the CDM
        self.open()
        # Provide the Certificate and Licence to the current CDM Session
        self.provide_certificate(self.certificate(self.get_certificate()))
        self.provide_license(self.license(self.get_license()))
        # Return Content Decryption Keys
        keys = []
        for key in self.get_keys():
            keys.append(key)
        return keys


class Cdm:

    system_id = [237, 239, 139, 169, 121, 214, 74, 206, 163, 200, 39, 220, 213, 29, 33, 237]
    urn = 'urn:uuid:EDEF8BA9-79D6-4ACE-A3C8-27DCD51D21ED'

    def __init__(self):
        self.sessions = {}
        self.device = None

    def open(self, init_data_b64, raw_init_data=None, offline=False):
        if self.device.session_id_type == 'android':
            # format: 16 random hexdigits, 2 digit counter, 14 0s
            session_id = (''.join(random.choice('ABCDEF0123456789') for _ in range(16)) +
                          "0100000000000000").encode('ascii')
        elif self.device.session_id_type == 'chrome':
            session_id = get_random_bytes(16)
        else:
            print("device type is unusable")
            return 1
        if raw_init_data and isinstance(raw_init_data, (bytes, bytearray)):
            # used for NF key exchange, where they don't provide a valid PSSH
            init_data = raw_init_data
            self.raw_pssh = True
        else:
            if init_data_b64 is not None:
                # Base64 Encoded PSSH to Bytes
                pssh = base64.b64decode(init_data_b64)
                # Make sure the PSSH is valid
                if pssh[12:28] != bytes(self.system_id):
                    t = bytearray([0, 0, 0])
                    t.append(32 + len(pssh))
                    t[4:] = bytearray(b'pssh')
                    t[8:] = [0, 0, 0, 0]
                    t[13:] = self.system_id
                    t[29:] = [0, 0, 0, 0]
                    t[31] = len(pssh)
                    t[32:] = pssh
                    init_data_b64 = base64.b64encode(t)
            init_data = self._parse_init_data(init_data_b64)
            self.raw_pssh = False

        if init_data:
            self.sessions[session_id] = Session(session_id, init_data, self.device, offline)
        else:
            print("unable to parse init data")
            return 1
        return session_id

    def _parse_init_data(self, init_data_b64):
        parsed_init_data = wv_proto2.WidevineCencHeader()
        try:
            # try parse init_data directly
            parsed_init_data.ParseFromString(base64.b64decode(init_data_b64)[32:])
        except DecodeError:
            # try with removed pssh box header
            try:
                id_bytes = parsed_init_data.ParseFromString(base64.b64decode(init_data_b64)[32:])
            except DecodeError:
                # unable to parse, unsupported init data format
                return None
        print("init_data:")
        for line in text_format.MessageToString(parsed_init_data).splitlines():
            print(line)
        return parsed_init_data

    def set_service_certificate(self, session_id, cert_b64):
        session = self.sessions[session_id]
        message = wv_proto2.SignedMessage()
        try:
            message.ParseFromString(base64.b64decode(cert_b64))
        except DecodeError:
            print("failed to parse cert as SignedMessage")
            return 1

        service_certificate = wv_proto2.SignedDeviceCertificate()

        if message.Type:
            # service cert provided as SignedMessage
            try:
                service_certificate.ParseFromString(message.Msg)
            except DecodeError:
                print("failed to parse service certificate")
                return 1
        else:
            # service cert provided as SignedDeviceCertificate
            try:
                service_certificate.ParseFromString(base64.b64decode(cert_b64))
            except DecodeError:
                print("failed to parse service certificate")
                return 1

        print("service certificate:")
        for line in text_format.MessageToString(service_certificate).splitlines():
            print(line)

        session.service_certificate = service_certificate
        session.privacy_mode = True

        return 0

    def get_license_request(self, session_id):
        session = self.sessions[session_id]
        # raw pssh will be treated as bytes and not parsed
        if self.raw_pssh:
            license_request = wv_proto2.SignedLicenseRequestRaw()
        else:
            license_request = wv_proto2.SignedLicenseRequest()
        client_id = wv_proto2.ClientIdentification()

        if not os.path.exists(session.device_config.device_client_id_blob_filename):
            print("no client ID blob available for this device")
            return 1

        with open(session.device_config.device_client_id_blob_filename, "rb") as f:
            try:
                cid_bytes = client_id.ParseFromString(f.read())
            except DecodeError:
                print("client id failed to parse as protobuf")
                return 1

        if not self.raw_pssh:
            license_request.Type = wv_proto2.SignedLicenseRequest.MessageType.Value('LICENSE_REQUEST')
            license_request.Msg.ContentId.CencId.Pssh.CopyFrom(session.init_data)
        else:
            license_request.Type = wv_proto2.SignedLicenseRequestRaw.MessageType.Value('LICENSE_REQUEST')
            license_request.Msg.ContentId.CencId.Pssh = session.init_data  # bytes

        license_request.Msg.ContentId.CencId.LicenseType = wv_proto2.LicenseType.Value('OFFLINE' if session.offline
                                                                                       else 'DEFAULT')
        license_request.Msg.ContentId.CencId.RequestId = session_id
        license_request.Msg.Type = wv_proto2.LicenseRequest.RequestType.Value('NEW')
        license_request.Msg.RequestTime = int(time.time())
        license_request.Msg.ProtocolVersion = wv_proto2.ProtocolVersion.Value('CURRENT')
        if session.device_config.send_key_control_nonce:
            license_request.Msg.KeyControlNonce = random.randrange(1, 2**31)

        if session.privacy_mode:
            if session.device_config.vmp:
                # vmp required, adding to client_id; reading vmp hashes
                vmp_hashes = wv_proto2.FileHashes()
                with open(session.device_config.device_vmp_blob_filename, "rb") as f:
                    try:
                        vmp_bytes = vmp_hashes.ParseFromString(f.read())
                    except DecodeError:
                        print("vmp hashes failed to parse as protobuf")
                        return 1
                client_id._FileHashes.CopyFrom(vmp_hashes)
            # privacy mode & service certificate loaded; encrypting client id
            print("unencrypted client id:")
            for line in text_format.MessageToString(client_id).splitlines():
                print(line)

            cid_aes_key = get_random_bytes(16)
            cid_iv = get_random_bytes(16)
            enc_client_id = wv_proto2.EncryptedClientIdentification()
            enc_client_id.ServiceId = session.service_certificate._DeviceCertificate.ServiceId
            enc_client_id.ServiceCertificateSerialNumber = session.service_certificate._DeviceCertificate.SerialNumber
            enc_client_id.EncryptedClientId = AES.new(cid_aes_key, AES.MODE_CBC, cid_iv).encrypt(
                Padding.pad(client_id.SerializeToString(), 16)
            )
            enc_client_id.EncryptedClientIdIv = cid_iv
            enc_client_id.EncryptedPrivacyKey = PKCS1_OAEP.new(
                RSA.importKey(session.service_certificate._DeviceCertificate.PublicKey)
            ).encrypt(cid_aes_key)
            license_request.Msg.EncryptedClientId.CopyFrom(enc_client_id)
        else:
            license_request.Msg.ClientId.CopyFrom(client_id)

        if session.device_config.private_key_available:
            session.device_key = RSA.importKey(open(session.device_config.device_private_key_filename).read())
        else:
            print("need device private key, other methods unimplemented")
            return 1

        # signing license request
        license_request.Signature = pss.new(session.device_key).sign(
            SHA1.new(license_request.Msg.SerializeToString())
        )
        session.license_request = license_request

        print("license request:")
        for line in text_format.MessageToString(session.license_request).splitlines():
            print(line)
        print(f"license request b64: {base64.b64encode(license_request.SerializeToString())}")
        return license_request.SerializeToString()

    def provide_license(self, session_id, license_b64):
        # decrypting provided license
        session = self.sessions[session_id]
        if not session.license_request:
            print("generate a license request first!")
            return 1
        license = wv_proto2.SignedLicense()
        try:
            license.ParseFromString(base64.b64decode(license_b64))
        except DecodeError:
            print("unable to parse license - check protobufs")
            return 1

        session.license = license

        print("license:")
        for line in text_format.MessageToString(license).splitlines():
            print(line)

        # deriving keys from session key
        session.session_key = PKCS1_OAEP.new(session.device_key).decrypt(license.SessionKey)

        lic_req_msg = session.license_request.Msg.SerializeToString()

        auth_key_base = b"AUTHENTICATION\0" + lic_req_msg + b"\0\0\2\0"
        auth_key_1 = b"\x01" + auth_key_base
        auth_key_2 = b"\x02" + auth_key_base
        auth_key_3 = b"\x03" + auth_key_base
        auth_key_4 = b"\x04" + auth_key_base

        cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
        cmac_obj.update(b"\x01" + b"ENCRYPTION\000" + lic_req_msg + b"\0\0\0\x80")

        enc_cmac_key = cmac_obj.digest()

        cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
        cmac_obj.update(auth_key_1)
        auth_cmac_key_1 = cmac_obj.digest()

        cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
        cmac_obj.update(auth_key_2)
        auth_cmac_key_2 = cmac_obj.digest()

        cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
        cmac_obj.update(auth_key_3)
        auth_cmac_key_3 = cmac_obj.digest()

        cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
        cmac_obj.update(auth_key_4)
        auth_cmac_key_4 = cmac_obj.digest()

        session.derived_keys['enc'] = enc_cmac_key
        session.derived_keys['auth_1'] = auth_cmac_key_1 + auth_cmac_key_2
        session.derived_keys['auth_2'] = auth_cmac_key_3 + auth_cmac_key_4

        # verifying license signature
        lic_hmac = HMAC.new(session.derived_keys['auth_1'], digestmod=SHA256)
        lic_hmac.update(license.Msg.SerializeToString())

        print("calculated sig: {} actual sig: {}".format(lic_hmac.hexdigest(), binascii.hexlify(license.Signature)))

        if lic_hmac.digest() != license.Signature:
            # license signature doesn't match - writing bin so they can be debugged
            with open("original_lic.bin", "wb") as f:
                f.write(base64.b64decode(license_b64))
            with open("parsed_lic.bin", "wb") as f:
                f.write(license.SerializeToString())
            # continuing anyway

        print("key count: {}".format(len(license.Msg.Key)))
        for key in license.Msg.Key:
            if key.Id:
                key_id = key.Id
            else:
                key_id = wv_proto2.License.KeyContainer.KeyType.Name(key.Type).encode('utf-8')
            key_type = wv_proto2.License.KeyContainer.KeyType.Name(key.Type)
            if key_type == "OPERATOR_SESSION":
                permissions = []
                for (descriptor, value) in key._OperatorSessionKeyPermissions.ListFields():
                    if value == 1:
                        permissions.append(descriptor.name)
            else:
                permissions = []
            session.keys.append(Key(
                key_id,
                key_type,
                Padding.unpad(AES.new(session.derived_keys['enc'], AES.MODE_CBC, iv=key.Iv).decrypt(key.Key), 16),
                permissions
            ))
        return 0

    def get_keys(self, session_id):
        return self.sessions[session_id].keys


class Session:
    def __init__(self, session_id, init_data, device_config, offline):
        self.session_id = session_id
        self.init_data = init_data
        self.offline = offline
        self.device_config = device_config
        self.device_key = None
        self.session_key = None
        self.derived_keys = {
            'enc': None,
            'auth_1': None,
            'auth_2': None
        }
        self.license_request = None
        self.license = None
        self.service_certificate = None
        self.privacy_mode = False
        self.keys = []


class Key:
    def __init__(self, kid, key_type, key, permissions=[]):
        self.kid = kid
        self.type = key_type
        self.key = key
        self.permissions = permissions

    def __repr__(self):
        if self.type == "OPERATOR_SESSION":
            return "key(kid={}, type={}, key={}, permissions={})".format(
                self.kid,
                self.type,
                binascii.hexlify(self.key),
                self.permissions
            )
        else:
            return "key(kid={}, type={}, key={})".format(self.kid, self.type, binascii.hexlify(self.key))


class Device:
    def __init__(self, cdm_directory):
        with open(os.path.join(cdm_directory, "wv.json"), 'rb') as f:
            cdm_device = json.loads(f.read())
            f.close()
        self.device_name = cdm_device['name']
        self.description = cdm_device['description']
        self.security_level = cdm_device['security_level']
        self.session_id_type = cdm_device['session_id_type']
        self.private_key_available = cdm_device['private_key_available']
        self.vmp = cdm_device['vmp']
        self.send_key_control_nonce = cdm_device['send_key_control_nonce']
        self.keybox_filename = os.path.join(cdm_directory, 'keybox')
        self.device_cert_filename = os.path.join(cdm_directory, 'device_cert')
        self.device_private_key_filename = os.path.join(cdm_directory, 'device_private_key')
        self.device_client_id_blob_filename = os.path.join(cdm_directory, 'device_client_id_blob')
        self.device_vmp_blob_filename = os.path.join(cdm_directory, 'device_vmp_blob')

    def __repr__(self):
        return "DeviceConfig(" + (", ".join([
          f"name={self.device_name}",
          f"description={self.description}",
          f"security_level={self.security_level}",
          f"session_id_type={self.session_id_type}",
          f"private_key_available={self.private_key_available}",
          f"vmp={self.vmp}"
        ])) + ")"
