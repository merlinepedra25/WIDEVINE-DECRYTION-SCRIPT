import requests


class AddOn(object):
    IDENTITY = "widevine_cdm_api"
    API_ENDPOINT = ""
    API_KEY = "" \
              ""

    def __init__(self, service, profile, device, proxy):
        self.session = requests.Session()
        self.service = service
        self.profile = profile
        self.device = device
        self.proxy = proxy
        # Stubs
        self.title_id = None
        self.title_type = None
        self.season = None
        self.episode = None

    def get_decryption_keys(self):
        """
        Call the API hosted Widevine CDM Object and return the decryption keys
        :return: decryption keys
        """
        api_response = self.session.post(
            url=f'{self.API_ENDPOINT}/',
            json={
                "api_key": self.API_KEY,
                "module": self.service,
                "profile": self.profile,
                "cdm_device": self.device,
                "proxy": self.proxy,
                "title": {
                    "id": self.title_id,
                    "type": self.title_type,
                    "season": self.season,
                    "episode": self.episode
                }
            }
        ).json()
        if not api_response["success"]:
            raise Exception(f"Widevine CDM API call failed:\n{api_response['message']}")
        return api_response['message']
