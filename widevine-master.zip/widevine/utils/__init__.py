class DictToObj(object):
    """
    Recursively convert a dictionary into an Object
    (no more foo["bar"], now its foo.bar)
    """
    def __repr__(self):
        return '{%s}' % str(', '.join("'%s': %s" % (k, repr(v)) for (k, v) in self.__dict__.items()))
    def __init__(self, data):
        for name, value in data.items():
            setattr(self, name, self._wrap(value))
    def _wrap(self, value):
        if isinstance(value, (tuple, list, set, frozenset)):
            return type(value)([self._wrap(v) for v in value])
        else:
            return DictToObj(value) if isinstance(value, dict) else value