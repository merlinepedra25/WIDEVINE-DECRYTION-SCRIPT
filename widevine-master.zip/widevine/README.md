# vinetrimmer
Widevine Decryption Script for Python 


# Modules
- Amazon
- Netflix (with h264@mpl support)
- Disney+
- VideoLand
- Boomerang
- RTE.ie

<p align="center">
    <img width="200" src="https://raw.githubusercontent.com/Kathryn-Jie/Kathryn-Jie/main/kathryn.png">
</p>

<h1> Hello Fellow < Developers/ >! </h1>
<p align='center'>
</p>



<div size='20px'> Hi! My name is WVDUMP. I am Leaking the scripts to punish few idiots :smile: 
</div>

<h2> About Me </h2>

<img width="55%" align="right" alt="Github" src="https://raw.githubusercontent.com/onimur/.github/master/.resources/git-header.svg" />

  
- 👯 Sharing is caring
  

- ⚡ CDM L1 BUY it from wvfuck@protonmail.com ⚡ 

  
<br>
<br>
  <br>

